import browser_cookie3

cookies = browser_cookie3.chrome(domain_name='.cyberlink.com')